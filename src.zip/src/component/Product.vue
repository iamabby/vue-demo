<template>
    <div>

      product

      <router-view></router-view>
    </div>
</template>




<script>
    export default{
        name:"Product"
    }
</script>