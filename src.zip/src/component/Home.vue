<template>
    <div>
      <!-- <swiper></swiper>-->
       <indexpro></indexpro>
    </div>
</template>



<script>

//import Swiper from "./Swiper";
import Indexpro from "./Indexpro";
import Tabs from "./Tabs";
export default {
    components:{
        name:"Home",
//      Swiper,
        Indexpro,
        Tabs
    }
}
</script>

<style lang="sass">

</style>

