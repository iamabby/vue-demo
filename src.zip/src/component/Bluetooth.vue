<template>
    <div>

        <h3>1321321321</h3>
    </div>
</template>




<script>
    export default{
        name:"Bluetooth"
    }
</script>