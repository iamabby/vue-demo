<template>
    <div>

      apps
    </div>
</template>




<script>
    export default{
        name:"Apps"
    }
</script>